export type DOC = {
  date: string;
  title: string;
  slug: string;
  description: string;
};
